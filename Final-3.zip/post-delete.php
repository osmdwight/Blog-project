<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['fname']) && $_GET['post_id']) {


    $post_id=$_GET['post_id'];

    include_once("postdata/post.php");
    include_once("db_conn.php");
    $res= deleteById($conn, $post_id);
    if($res){
        $sm="Successfully deleted!";
        header("Location: createpost.php?success=$sm");
        exit;
    }else{
        $em="Unknown error occured";
        header("Location: createpost.php?error=$sm");
        exit;
    }

}else{
    header("Location: login.php");
    exit;
}














 

