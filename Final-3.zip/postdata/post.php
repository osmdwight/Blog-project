<?php

//getAll Users
function getAll($conn){
	$sql="SELECT * FROM post ORDER BY crated_at DESC";
	$stmt= $conn->prepare($sql);
	$stmt->execute();

	if($stmt->rowCount()>=1){
		$data=$stmt->fetchAll();
		return $data;
	}else {
		return 0;
	}
}

function getById($conn,$post_id){
	$sql="SELECT * FROM post WHERE post_id=?";
	$stmt= $conn->prepare($sql);
	$stmt->execute([$post_id]);

	if($stmt->rowCount()>=1){
		$data=$stmt->fetch();
		return $data;
	}else {
		return 0;
	}
}
// Delete by ID
function deleteById($conn, $post_id) {
    $sql = "DELETE FROM post WHERE post_id=?";
    $stmt = $conn->prepare($sql);
    $res = $stmt->execute([$post_id]);

	if($res){
		return 1;
	}else{
		return 0;
	}
}








?>


