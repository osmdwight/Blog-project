<?php 
session_start();
$logged = false;
if (isset($_SESSION['id']) && isset($_SESSION['fname'])) {
	 $logged = true;
	 $user_id = $_SESSION['id'];
    }
  $notFound = 0;
 ?>
<!DOCTYPE html>
<html lang ="en">
		<head>
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title>Blog Page</title>
			<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
			<link rel="stylesheet"href="css/style.css">

			<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
			<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

			<style>
			body {font-family: "Lato", sans-serif}
			.mySlides {display: none}
			</style>

		</head>
<body>
	<?php 
 
      include_once("postdata/post.php");
      include_once("db_conn.php");
      $posts = getAll($conn);
     
       
	 ?>
	<nav class="navbar navbar-expand-lg bg-body-tertiary">
	  <div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="index.php" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    <a href="blog.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">BLOGS</a>
    <a href="aboutus.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">ABOUT</a>
    <a href="index.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">CONTACT</a>
     <a href="login.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">LOG IN | SIGN UP</a>
    <a href="javascript:void(0)" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fa fa-search"></i></a>
  </div>
</div>
	</nav>
	  <div class="container mt-5">		
	  	<section class="d-flex">
  	   <main class="main-blog">
	  	   	<?php foreach ($posts as $post) { ?>
	  	   	   <div class="card main-blog-card mb-5">
				  <img src="upload/blog/<?=$post['cover_url']?>" class="card-img-top" alt="...">
				  <div class="card-body">
				    <h5 class="card-title"><?=$post['post_title']?></h5>
				    <?php 
	                    $p = strip_tags($post['post_text']); 
	                    $p = substr($p, 0, 200);               
				     ?>
				    <p class="card-text"><?=$p?>...</p>
				    <a href="blog-view.php?post_id=<?=$post['post_id']?>" class="btn btn-primary">Read more</a>
				    <hr>
	                <div class="d-flex justify-content-between">	
							    <small class="text-body-secondary"><?=$post['crated_at']?></small>
	                </div>	
				    
				  </div>
				</div>
			<?php } ?>
			  	   </main>

				  	</section>
	  </div>



</nav>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>