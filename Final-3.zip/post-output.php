<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['fname'])) {
if(isset($_POST['title']) && 
   isset($_FILES['cover']) && 
   isset($_POST['text'])){


    $title=$_POST['title'];
    $text=$_POST['text'];


    if(empty($title)){
            $em="Title is required!";
            header("Location: post.php?error=$sm");
            exit;
    }else if (empty($title)){
        $em="Title is required!";
            header("Location: post.php?error=$em");
            exit;
    }

    if($_FILES['cover']['name']==""){
        //file uplaod
        $res=0;
    }else{
            $sql="INSERT INTO post(post_title, post_text) VALUES (?,?)";
            $stmt= $conn->prepare($sql);
            $res->execute([$title, $text]);
    }
       if($res){
            $sm="Successfully Created!";
            header("Location: post.php?success=$sm");
            exit;
        }else{
            $em="Unknown error occured";
            header("Location: spost.php?error=$sm");
            exit;
        }

    

}else{
    header("Location:post-add.php");
}


}else {
   header("Location: login.php");
   exit;
} 