<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #1a1a1a; 
            color: #fff; 
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 0;
            padding: 0;
            background-image: url('bg.jpg'); 
            background-size: cover; 
            background-repeat: no-repeat; 
            background-attachment: fixed; 
            opacity: 1; 
        }

        h1 {
            margin-top: 50px;
            font-size: 2em;
            letter-spacing: 2px;
        }

        .people-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            margin: 50px 0;
        }

        .person {
            background-color: #333; 
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            border-radius: 15px;
            overflow: hidden;
            margin: 20px;
            width: 300px;
            transition: transform 0.3s ease-in-out;
        }

        .person:hover {
            transform: scale(1.05);
        }

        .person img {
            max-width: 100%;
            height: auto;
            border-radius: 15px 15px 0 0;
        }

        h2 {
            color: #fff;
            margin-top: 15px;
        }

        p {
            color: #ccc; /* Light gray text color */
            padding: 20px;
            margin: 0;
        }

        .links {
            background-color: #282828; 
            padding: 10px;
            text-align: center;
        }

        .links a {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
        }

        .summary {
            background-color: #333; 
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            border-radius: 15px;
            overflow: hidden;
            margin: 20px;
            padding: 20px;
            width: 80%;
        }
    </style>
</head>
<body>

    <h1>About Us</h1>

    <div class="people-container">

        <div class="person">
            <img src="madman.png">
            <h2>Dwight Gonzales</h2>
            <p>
               I'm Dwight Gonzales, the founder of our amazing blog. I share a passion for technology with my friends and love sharing my insights with our readers. Follow us for the latest rap updates.
            </p>
           
        </div>

        <div class="person">
            <img src="cashman.png" >
            <h2>Andrei Ablian</h2>
            <p>
                I'm Andrei Ablian, coder and partners with Dwight and John. We are excited for you to join us on a journey through exciting destinations and lifestyle tips that will make your life more vibrant using this blog.

            </p>
           
        </div>

        <div class="person">
            <img src="gee.png" >
            <h2>John Quintero</h2>
            <p>
                I'm John Quintero, a coding enthusiast that joined the group. Expect our thoughts and indights on this blog and if you have any questions, we've got you covered.
            </p>
           
        </div>

    </div>

    <div class="summary">
        <h2>WHO WE ARE</h2>
        <p>
            As a trio passionate about various projects, we've united our efforts to channel our focus into creating a dynamic rap-centric blog. Our platform aims to engage readers with insightful opinions on crucial topics within the rap scene, drawing from our collective knowledge. We're committed to a journey of mutual learning and exploration, fostering success through harmonious collaboration and prioritizing productivity and creativity to meet our readers' needs. If you have any questions or want to join the rap conversation, feel free to reach out – we're here to connect and share our love for the craft.
        </p>
    </div>

</body>
</html>
