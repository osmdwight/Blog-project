<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['fname'])) 
{

   
?>



   <!DOCTYPE html>
   <html>
   <head>
      <title>Dashboard</title>
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
      <link rel="stylesheet" href="../css/side-bar.css">
      <link rel="stylesheet" href="../css/style.css">
   </head>

   <body>
      <?php 
            include("side-nave.php");    
            include_once("postdata/post.php");
            include_once("db_conn.php");
            $posts= getAll($conn);
      ?>
      <div class="main-table">
         <h3 class="mb-3">Create Post <a href="post-add.php" class="btn btn-success">Add New</a></h3>
         <?php if ($posts !=0){ ?>
            <table class="table t1 table-bordered">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Title</th>
                  <th scope="col">Description</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>     
              <tbody>

                   <?php foreach ($posts as $post) { ?>
                <tr>
                  <th scope="row"><?=$post['post_id']?></th>
                  <td><a href="single_post.php?post_id=<?=$post['post_id']?>"><?=$post['post_title']?></a></td>
                  <td>               
                     <?php 
                              $p = strip_tags($post['post_text']); 
                              $p = substr($p, 0, 200);               
                     ?>
                     <p class="card-text"><?=$p?>...</p>
                     </td>

                  </td>          


                  <td>
                     <a href="javascript:void(0);" onclick="confirmDelete(<?=$post['post_id']?>)" class="btn btn-danger">Delete</a>
                       <a href="post-edit.php?post_id=<?=$post['post_id']?>"
                      class="btn btn-warning">Edit</a>

                  </td>
                </tr>
             <?php }?>
              </tbody>
            </table>
         <?php }else{ ?>
            <div class="alert alert-info">
               Empty!
         </div>
         <?php } ?>
   </body>
   <script>
        function confirmDelete(post_id) {
            var confirmation = confirm('Are you sure you want to delete this post?');
            if (confirmation) {
                window.location.href = 'post-delete.php?post_id=' + post_id;
            }
        }
      </script>"
   </html>
<?php }else {
   header("Location: login.php");
   exit;
} ?>